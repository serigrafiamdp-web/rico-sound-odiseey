#!/usr/bin/env python3
"""Rebuild RICO Sound Odyssey MIDI DATEL TEST08 exactly from the original ISEPIC PRG.
Usage: python rebuild_SOUND_DATEL_TEST08_from_original.py "sound(1).PRG" "TEST08.PRG"
No third party dependencies. Never modifies the original PRG.
"""
import sys, hashlib
from pathlib import Path

ORIG_SHA = 'dfa940539024d63f249b029188bc12e391a9671489f93c96cf1694d2641080a3'
TEST08_SHA = 'b9a3cfe3dadb90b379674f90ff5cfd35b16d74a82d0dbd8b3c79b562f1de77d0'
MIDI_PATCH = bytes.fromhex('''
48 8a 48 ad f4 25 d0 17 a9 03 8d 04 de a2 00 ca d0 fd a9 16 8d 04 de a9 ff 8d f5 25 ee f4 25 ad 06 de 29 01 f0 06 ad 07 de 20 7c 25 68 aa 68 20 7b 00 ec f5 25 d0 02 a9 00 09 00 60 c9 f8 b0 1f c9 80 90 1c c9 f0 b0 0d 8d f6 25 29 f0 c9 80 f0 09 c9 90 f0 05 a9 00 8d f6 25 a9 00 8d f7 25 60 ae f6 25 f0 fa ae f7 25 d0 07 8d f8 25 ee f7 25 60 48 a9 00 8d f7 25 ad f8 25 38 e9 0c 90 33 c9 12 b0 2f 8d f9 25 ad f6 25 29 f0 c9 80 f0 0f 68 f0 0d ad f9 25 8d f5 25 a9 05 8d 20 d0 60 68 ad f9 25 cd f5 25 d0 0a a9 ff 8d f5 25 a9 06 8d 20 d0 60 68 60 00 ff 00 00 00 00
''')
assert len(MIDI_PATCH)==186

def unpack(src):
    mem=bytearray(65536)
    load=int.from_bytes(src[:2],'little')
    mem[load:load+len(src)-2]=src[2:]
    for i in range(0xf600): mem[0x039e+i]=mem[0x089e+i]
    p,q=0x9751,0xffff
    while True:
        mem[q]=mem[p];p=(p-1)&65535;q=(q-1)&65535
        if (p>>8)==9:break
    mem[0x0702]=(q+1)&255;mem[0x0703]=(q+1)>>8
    mem[:256]=mem[0x700:0x800]
    readptr=mem[2]|mem[3]<<8
    writeptr=mem[4]|mem[5]<<8
    while (writeptr>>8)!=0xff:
        c=mem[readptr];readptr+=1
        if c&0x80:
            n=(c&63)+1
            if c&0x40:
                mem[writeptr:writeptr+n]=mem[readptr:readptr+n];writeptr+=n;readptr+=n
            else:
                value=mem[readptr];readptr+=1
                mem[writeptr:writeptr+n]=bytes([value])*n;writeptr+=n
        elif c&0x40:
            mem[writeptr:writeptr+256]=mem[readptr:readptr+256];writeptr+=256;readptr+=256
        else:
            n=(c&63)+1
            for _ in range(n):mem[writeptr]=(writeptr&255)^((writeptr>>8)&255);writeptr+=1
    assert writeptr==0xff00
    return mem

def pack(data):
    N=len(data);cost=[10**12]*(N+1);cost[N]=0;choices=[None]*N
    xor_run=[0]*(N+1);repeat_run=[0]*(N+1)
    for i in range(N-1,-1,-1):
        address=i+0x100
        if data[i]==((address&255)^(address>>8)):xor_run[i]=1+xor_run[i+1]
        repeat_run[i]=(1 if i==N-1 or data[i]!=data[i+1] else 1+repeat_run[i+1])
        best=10**12;chosen=None
        for n in range(1,min(64,N-i)+1):
            test=1+n+cost[i+n]
            if test<best:best=test;chosen=('literal',n)
        if N-i>=256 and 257+cost[i+256]<best:best=257+cost[i+256];chosen=('block',256)
        for n in range(1,min(64,xor_run[i])+1):
            test=1+cost[i+n]
            if test<best:best=test;chosen=('xor',n)
        for n in range(1,min(64,repeat_run[i])+1):
            test=2+cost[i+n]
            if test<best:best=test;chosen=('repeat',n)
        cost[i]=best;choices[i]=chosen
    out=bytearray();i=0
    while i<N:
        kind,n=choices[i]
        if kind=='literal':out.append(0xc0+n-1);out+=data[i:i+n]
        if kind=='block':out.append(0x40);out+=data[i:i+256]
        if kind=='repeat':out.extend([0x80+n-1,data[i]])
        if kind=='xor':out.append(n-1)
        i+=n
    assert len(out)==cost[0]
    return out

def main():
    if len(sys.argv)<2:
        print('Usage: python rebuild_SOUND_DATEL_TEST08_from_original.py "sound(1).PRG" [output.PRG]')
        sys.exit(2)
    input_path=Path(sys.argv[1])
    out=Path(sys.argv[2] if len(sys.argv)>2 else 'SOUND_ODYSSEY_DATEL_MIDI_TEST08_C0_POLLING.PRG')
    original=input_path.read_bytes()
    assert hashlib.sha256(original).hexdigest()==ORIG_SHA,'ERROR: not the exact original snapshot!'
    mem=unpack(original)
    assert mem[0x2540:0x2540+len(MIDI_PATCH)]==bytes(len(MIDI_PATCH)), 'patch area not empty'
    assert mem[0x486e:0x4871]==b'\x20\x7b\x00', 'wrong keyboard hook'
    mem[0x486e:0x4871]=bytes((0x20,0x40,0x25))
    mem[0x2540:0x2540+len(MIDI_PATCH)]=MIDI_PATCH
    compressed=pack(mem[0x100:0xff00]); capacity=0x8d49
    assert len(compressed)<=capacity
    shift=capacity-len(compressed)
    prg=bytearray(original);load=int.from_bytes(prg[:2],'little')
    def pos(addr):return 2+addr-load
    base=pos(0x0f00)
    prg[base:base+capacity]=b'\x00'*capacity
    prg[base+shift:base+shift+len(compressed)]=compressed
    p1,p2=pos(0x0ad7),pos(0x0ade)
    assert original[p1:p1+2]==b'\x69\x01' and original[p2:p2+2]==b'\x69\x00'
    prg[p1+1]=(shift+1)&255;prg[p2+1]=(shift+1)>>8
    digest=hashlib.sha256(prg).hexdigest()
    assert digest==TEST08_SHA,f'Unexpected output checksum: {digest}'
    assert out.resolve()!=input_path.resolve(),'Refuse overwriting source'
    out.write_bytes(prg)
    print(f'PASS — {out} ({len(prg)} bytes), SHA256 {digest}')

if __name__=='__main__':main()
